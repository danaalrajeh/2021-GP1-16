<!DOCTYPE html>
<html>
<head>
	<title>home</title>
  <link rel="stylesheet" href="style.css">
<style type="text/css">

 
</style>

</head>
<body class="one" style="padding: 0px; margin: 0px;">

<div class="navbar_home">
  <a href="index.php"><i class="fa fa-fw fa-user"></i><img src="img\logo.png" height="150"></a>
  <a  href="index.php" class="active_home">Features</a>  
</div>
<div>
<div id="inl_home" align="center"><img  style="border-radius: 40px;" src="img\home1.png" width="400" height="250"></div>
<div id="inl1_home"><img  style="margin-left: 70%;border-radius: 40px;" src="img\logo_f.png" width="400" height="250"></div>
</div><br><br>
<div align="center">
 <a class="btn_home" href="login.php">Log in</a><br><br><br>
<a class="btn_home" href="create_accuont.php">Signup</a> 
</div>




</body>
</html>